﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desktopapplication.Order
{
    internal class OrderModel
    {

        public int id { get; set; }
        public string customername { get; set; }
        public string contact { get; set; }
        public string address { get; set; }



        public List<OrderItem> ordersList = new List<OrderItem>();
        public OrderModel()
        {

        }
        public OrderModel(int id, string customername, string contact, string address)
        {

            this.id = id;
            this.customername = customername;
            this.contact = contact;
            this.address = address;

        }
        public OrderModel(string customername, string contact, string address)
        {
            this.customername = customername;
            this.contact = contact;
            this.address = address;

        }
        public void AddOrder(OrderItem item)
        {
            ordersList.Add(item);
        }
        public override string ToString()
        {
            return $"{customername},{contact},{address}";
        }
        public string CombineOrderToString()
        {
            string data = customername + "," + contact + "," + address + ",";
            foreach (OrderItem item in ordersList)
            {
                data += item.product + "," + item.quantity + "," + item.salePrice;
            }
            return data;
        }
        public static OrderModel SplitOrderData(string customerDetails, string itemDetails)
        {
            //string customername = "";
            string contact = "";
            string address = "";
            try
            {
                string[] customerParts = customerDetails.Split(',');
                //if(customerParts.Length > 0)
                //{
                //    customername = customerParts[0];

                //}
                if (customerParts.Length > 0)

                    contact = customerParts[0];


                if (customerParts.Length > 1)

                    address = customerParts[1];

                OrderModel order = new OrderModel("", contact, address);
                string[] allitems = itemDetails.Split(';');
                foreach (string oneItem in allitems)
                {
                    //if (oneItem == "") continue;
                    if (string.IsNullOrWhiteSpace(oneItem))
                        continue;
                    string[] parts = oneItem.Split(',');

                    if (parts.Length < 3)
                        continue;

                    string product = parts[0].Trim();
                    int quantity = 0;
                    int price = 0;
                    try
                    {
                        quantity = int.Parse(parts[1].Trim());
                        price = int.Parse(parts[2].Trim());
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine($"Invalid number found in : {oneItem}");
                        continue;
                    }
                    OrderItem item = new OrderItem(product, quantity, price);
                    order.AddOrder(item);
                }
                return order;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while splitting order data: " + ex.Message);
                return null;
            }
        }
    }
}

