﻿using desktopapplication.Customer;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Order
{
    public partial class OrderForm : Form
    {
        OrderRepo repo = new OrderRepo();
        //string DBconnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public OrderForm()
        {
            InitializeComponent();
        }
        //UPDATE
        private void button2_Click(object sender, EventArgs e)
        {

            // Get ID from textbox or selected grid row
            int id = int.Parse(txtboxdeleteorupdate.Text);

            string customerName = txtboxcustomername.Text.Trim();
            string contact = txtboxcontact.Text.Trim();
            string address = txtboxaddress.Text.Trim();
            string itemName = txtboxitemname.Text.Trim();
            string quantity = txtboxquantity.Text.Trim();
            string salePrice = txtboxitemprice.Text.Trim();

            // Combine details
            string customerDetails = $"Contact:{contact}, Address:{address}";
            string itemDetails = $"Quantity:{quantity}, SalePrice:{salePrice}";

            string connectionString = @"Data Source=localhost;Initial Catalog=PointOfSale;Integrated Security=True;TrustServerCertificate=True;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"UPDATE ORDERDETAILS 
                             SET customername = @customername,
                                 customerdetails = @customerdetails,
                                 itemname = @itemname,
                                 itemdetails = @itemdetails
                             WHERE id = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@customername", customerName);
                        cmd.Parameters.AddWithValue("@customerdetails", customerDetails);
                        cmd.Parameters.AddWithValue("@itemname", itemName);
                        cmd.Parameters.AddWithValue("@itemdetails", itemDetails);
                        cmd.Parameters.AddWithValue("@id", id);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show("Order updated successfully!");
                            //LoadOrders(); // Refresh DataGridView after update
                        }
                        else
                        {
                            MessageBox.Show("Update failed.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtboxdeleteorupdate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtboxcustomerdetails_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblorderitem_Click(object sender, EventArgs e)
        {

        }
        //ADD
        private void btnAdd_Click(object sender, EventArgs e)
        {

            string customerName = txtboxcustomername.Text.Trim();
            string contact = txtboxcontact.Text.Trim();
            string address = txtboxaddress.Text.Trim();
            string itemName = txtboxitemname.Text.Trim();
            string quantity = txtboxquantity.Text.Trim();
            string salePrice = txtboxitemprice.Text.Trim();

            // Combine details
            string customerDetails = $"Contact:{contact},Address{address} ";
            string itemDetails = $"Quantity:{quantity},SalePrice{salePrice}";

            // Connection string
            string connectionString = @"Data Source=localhost;Initial Catalog=PointOfSale;Integrated Security=True;TrustServerCertificate=True;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = @"INSERT INTO ORDERDETAILS 
                         (customername, customerdetails, itemname, itemdetails) 
                         VALUES (@customername, @customerdetails, @itemname, @itemdetails)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@customername", customerName);
                        cmd.Parameters.AddWithValue("@customerdetails", customerDetails);
                        cmd.Parameters.AddWithValue("@itemname", itemName);
                        cmd.Parameters.AddWithValue("@itemdetails", itemDetails);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                            MessageBox.Show("Order added successfully!");
                        else
                            MessageBox.Show("Failed to add order.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void btnviewall_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost;Initial Catalog=PointOfSale;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM ORDERDETAILS";

                using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;   // Load data into grid
                }
            }
        }

        private void txtboxcontact_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtboxaddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=localhost;Initial Catalog=PointOfSale;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                string query = "SELECT * FROM ORDERDETAILS";

                using (SqlDataAdapter da = new SqlDataAdapter(query, conn))
                {
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;   // Load data into grid
                }
            }
        }
        //DELETE 
        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale sale = new PointOfSale();
            sale.Show();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtboxdeleteorupdate.Text))
            {
                MessageBox.Show("Please enter an ID to delete.");
                return;
            }

            int id = int.Parse(txtboxdeleteorupdate.Text);

            string connectionString = @"Data Source=localhost;Initial Catalog=PointOfSale;Integrated Security=True;TrustServerCertificate=True;";

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string query = "DELETE FROM ORDERDETAILS WHERE id = @id";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);

                        int rows = cmd.ExecuteNonQuery();

                        if (rows > 0)
                        {
                            MessageBox.Show("Record deleted successfully!");

                            // Optional: Refresh your grid
                            // LoadOrders();

                            // Optional: Clear textboxes
                            // ClearInputs();
                        }
                        else
                        {
                            MessageBox.Show("No record found with this ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }

}

