﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desktopapplication.Order
{
    internal class OrderRepo
    {
        private readonly string _file = @"C:\Users\User\Desktop\AimanSiddiqua\order.txt";

        public void Save(OrderModel order)
        {
            using (StreamWriter writer = new StreamWriter(_file, true))
            {
                string customerdetails = $"customer,{order.customername},{order.contact},{order.address}";
                writer.WriteLine(customerdetails);
                foreach (OrderItem items in order.ordersList)
                {
                    string itemdetails = $"item,{items.product},{items.quantity},{items.salePrice},{items.quantity * items.salePrice}";
                    writer.WriteLine(itemdetails);
                }
            }
        }
        public List<OrderModel> GetAllOrders()
        {

            List<OrderModel> orders = new List<OrderModel>();
            using (StreamReader reader = new StreamReader(_file))
            {
                string line = "";
                OrderModel temporder = null;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.StartsWith("customer"))
                    {
                        string[] parts = line.Split(',');
                        string name = parts[1];
                        string contact = parts[2];
                        string address = parts[3];
                        temporder = new OrderModel(name, contact, address);
                        orders.Add(temporder);
                    }
                    else if (line.StartsWith("item"))
                    {
                        string[] parts = line.Split(',');

                        string product = parts[1];
                        int quantity = int.Parse(parts[2]);
                        int price = int.Parse(parts[3]);
                        OrderItem obj = new OrderItem(product, quantity, price);
                        temporder.AddOrder(obj);
                    }
                }
                return orders;
            }
        }
        public readonly string DbConnection = "Server=LocalHost;Database=PointOfSale;Trusted_Connection=True";
        public bool Create(OrderModel order, OrderItem orderitem)
        {
            using (SqlConnection conn = new SqlConnection(DbConnection))
            {
                string query = "INSERT INTO ORDERDETAILS (customername, customerdetails, itemname, itemdetails)" +
                    "VALUES (@customername, @customerdetails, @itemname, @itemdetails)";

                SqlCommand cmd = new SqlCommand(query, conn);
                string customerdetails = $"Contact: {order.contact},Address: {order.address}";
                string itemdetails = $"Quantity:{orderitem.quantity},SalePrice:{orderitem:salePrice}";
                cmd.Parameters.AddWithValue("@customername", order.customername);
                cmd.Parameters.AddWithValue("@customerdetails", customerdetails);
                cmd.Parameters.AddWithValue("@itemname", orderitem.product);
                cmd.Parameters.AddWithValue("@itemdetails", itemdetails);

                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public bool Update(OrderModel order, OrderItem orderitem)
        {
            using (SqlConnection conn = new SqlConnection(DbConnection))
            {
                string query = "UPDATE ORDERDETAILS SET customername= @customername, customerdetails=@customerdetails, itemname=@itemname, itemdetails=@itemdetails WHERE Id = @Id";
                SqlCommand cmd = new SqlCommand(query, conn);
                string customerdetails = $"Contact: {order.contact},Address: {order.address}";
                string itemdetails = $"Quantity:{orderitem.quantity},SalePrice:{orderitem:salePrice}";
                cmd.Parameters.AddWithValue("@id", order.id);
                cmd.Parameters.AddWithValue("@customername", order.customername);
                cmd.Parameters.AddWithValue("@customerdetails", customerdetails);
                cmd.Parameters.AddWithValue("@itemname", orderitem.product);
                cmd.Parameters.AddWithValue("@itemdetails", itemdetails);
                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        public bool Delete(int id)
        {
            using (SqlConnection conn = new SqlConnection(DbConnection))
            {
                string query = "DELETE FROM ORDERDETAILS WHERE id = @id";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                conn.Open();
                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }



        public List<OrderModel> GetAll()
        {
            List<OrderModel> orders = new List<OrderModel>();
            using (SqlConnection conn = new SqlConnection(DbConnection))
            {
                string query = "SELECT id, customername, customerdetails,itemname, itemdetails FROM ORDERDETAILS";
                SqlCommand cmd = new SqlCommand(query, conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    string customername = reader["customername"].ToString();
                    string customerdetails = reader["customerdetails"].ToString();
                    string itemname = reader["itemname"].ToString();
                    string itemdetails = reader["itemdetails"].ToString();
                    //call splitorderdata() function from orderModel
                    OrderModel order = OrderModel.SplitOrderData(customerdetails, itemdetails);
                    //set id and customer name
                    order.id = id;
                    order.customername = customername;
                    orders.Add(order);
                }

                reader.Close();
            }
            return orders;

        }
    }
}
