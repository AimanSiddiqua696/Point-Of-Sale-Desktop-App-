﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desktopapplication.Order
{
    internal class OrderItem
    {
        public string product { get; set; }

        public int quantity { get; set; }
        public int salePrice { get; set; }
        public OrderItem()
        {

        }
        public OrderItem(string product, int quantity, int salePrice)
        {
            this.product = product;

            this.quantity = quantity;
            this.salePrice = salePrice;

        }
        public override string ToString()
        {
            return $"{product},{quantity},{salePrice}";
        }
    }
}
