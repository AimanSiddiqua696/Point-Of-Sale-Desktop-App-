﻿namespace desktopapplication.Order
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblcustomername = new Label();
            lblcontact = new Label();
            lblitemname = new Label();
            lblquantity = new Label();
            txtboxcustomername = new TextBox();
            txtboxitemname = new TextBox();
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnupdate = new Button();
            btndelete = new Button();
            btnviewall = new Button();
            btnback = new Button();
            lblId = new Label();
            txtboxdeleteorupdate = new TextBox();
            txtboxcontact = new TextBox();
            txtboxquantity = new TextBox();
            txtboxitemprice = new TextBox();
            txtboxaddress = new TextBox();
            lbladdress = new Label();
            lblsaleprice = new Label();
            btncheckorder = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(289, 61);
            label1.Name = "label1";
            label1.Size = new Size(556, 48);
            label1.TabIndex = 0;
            label1.Text = "ORDER MANAGEMENT SYSTEM";
            // 
            // lblcustomername
            // 
            lblcustomername.AutoSize = true;
            lblcustomername.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcustomername.Location = new Point(15, 151);
            lblcustomername.Name = "lblcustomername";
            lblcustomername.Size = new Size(148, 25);
            lblcustomername.TabIndex = 1;
            lblcustomername.Text = "Customer Name";
            // 
            // lblcontact
            // 
            lblcontact.AutoSize = true;
            lblcontact.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblcontact.Location = new Point(17, 227);
            lblcontact.Name = "lblcontact";
            lblcontact.Size = new Size(78, 25);
            lblcontact.TabIndex = 2;
            lblcontact.Text = "Contact";
            // 
            // lblitemname
            // 
            lblitemname.AutoSize = true;
            lblitemname.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblitemname.Location = new Point(15, 318);
            lblitemname.Name = "lblitemname";
            lblitemname.Size = new Size(106, 25);
            lblitemname.TabIndex = 3;
            lblitemname.Text = "Item Name";
            // 
            // lblquantity
            // 
            lblquantity.AutoSize = true;
            lblquantity.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblquantity.Location = new Point(17, 360);
            lblquantity.Name = "lblquantity";
            lblquantity.Size = new Size(87, 25);
            lblquantity.TabIndex = 4;
            lblquantity.Text = "Quantity";
            lblquantity.Click += lblorderitem_Click;
            // 
            // txtboxcustomername
            // 
            txtboxcustomername.Location = new Point(219, 151);
            txtboxcustomername.Name = "txtboxcustomername";
            txtboxcustomername.Size = new Size(210, 31);
            txtboxcustomername.TabIndex = 5;
            // 
            // txtboxitemname
            // 
            txtboxitemname.Location = new Point(222, 315);
            txtboxitemname.Name = "txtboxitemname";
            txtboxitemname.Size = new Size(210, 31);
            txtboxitemname.TabIndex = 7;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.Control;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(499, 199);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(574, 330);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(166, 555);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(112, 34);
            btnAdd.TabIndex = 10;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnupdate
            // 
            btnupdate.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnupdate.Location = new Point(317, 554);
            btnupdate.Name = "btnupdate";
            btnupdate.Size = new Size(112, 34);
            btnupdate.TabIndex = 11;
            btnupdate.Text = "Update";
            btnupdate.UseVisualStyleBackColor = true;
            btnupdate.Click += button2_Click;
            // 
            // btndelete
            // 
            btndelete.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btndelete.Location = new Point(480, 555);
            btndelete.Name = "btndelete";
            btndelete.Size = new Size(112, 34);
            btndelete.TabIndex = 12;
            btndelete.Text = "Delete";
            btndelete.UseVisualStyleBackColor = true;
            btndelete.Click += btndelete_Click;
            // 
            // btnviewall
            // 
            btnviewall.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnviewall.Location = new Point(652, 555);
            btnviewall.Name = "btnviewall";
            btnviewall.Size = new Size(112, 34);
            btnviewall.TabIndex = 13;
            btnviewall.Text = "View All";
            btnviewall.UseVisualStyleBackColor = true;
            btnviewall.Click += btnviewall_Click;
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(847, 555);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 14;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblId.Location = new Point(12, 473);
            lblId.Name = "lblId";
            lblId.Size = new Size(201, 28);
            lblId.TabIndex = 15;
            lblId.Text = "id(delete or update)";
            lblId.Click += label2_Click;
            // 
            // txtboxdeleteorupdate
            // 
            txtboxdeleteorupdate.Location = new Point(219, 473);
            txtboxdeleteorupdate.Name = "txtboxdeleteorupdate";
            txtboxdeleteorupdate.Size = new Size(207, 31);
            txtboxdeleteorupdate.TabIndex = 16;
            txtboxdeleteorupdate.TextChanged += txtboxdeleteorupdate_TextChanged;
            // 
            // txtboxcontact
            // 
            txtboxcontact.Location = new Point(220, 221);
            txtboxcontact.Name = "txtboxcontact";
            txtboxcontact.Size = new Size(150, 31);
            txtboxcontact.TabIndex = 17;
            txtboxcontact.TextChanged += txtboxcontact_TextChanged;
            // 
            // txtboxquantity
            // 
            txtboxquantity.Location = new Point(222, 357);
            txtboxquantity.Name = "txtboxquantity";
            txtboxquantity.Size = new Size(150, 31);
            txtboxquantity.TabIndex = 19;
            // 
            // txtboxitemprice
            // 
            txtboxitemprice.Location = new Point(219, 405);
            txtboxitemprice.Name = "txtboxitemprice";
            txtboxitemprice.Size = new Size(150, 31);
            txtboxitemprice.TabIndex = 20;
            txtboxitemprice.TextChanged += textBox2_TextChanged;
            // 
            // txtboxaddress
            // 
            txtboxaddress.Location = new Point(222, 267);
            txtboxaddress.Name = "txtboxaddress";
            txtboxaddress.Size = new Size(150, 31);
            txtboxaddress.TabIndex = 18;
            txtboxaddress.TextChanged += txtboxaddress_TextChanged;
            // 
            // lbladdress
            // 
            lbladdress.AutoSize = true;
            lbladdress.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbladdress.Location = new Point(17, 270);
            lbladdress.Name = "lbladdress";
            lbladdress.Size = new Size(80, 25);
            lbladdress.TabIndex = 21;
            lbladdress.Text = "Address";
            // 
            // lblsaleprice
            // 
            lblsaleprice.AutoSize = true;
            lblsaleprice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblsaleprice.Location = new Point(17, 405);
            lblsaleprice.Name = "lblsaleprice";
            lblsaleprice.Size = new Size(94, 25);
            lblsaleprice.TabIndex = 22;
            lblsaleprice.Text = "Sale Price";
            // 
            // btncheckorder
            // 
            btncheckorder.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btncheckorder.Location = new Point(626, 131);
            btncheckorder.Name = "btncheckorder";
            btncheckorder.Size = new Size(261, 51);
            btncheckorder.TabIndex = 23;
            btncheckorder.Text = "Check Order";
            btncheckorder.UseVisualStyleBackColor = true;
            btncheckorder.Click += button1_Click;
            // 
            // OrderForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(1149, 712);
            Controls.Add(btncheckorder);
            Controls.Add(lblsaleprice);
            Controls.Add(lbladdress);
            Controls.Add(txtboxitemprice);
            Controls.Add(txtboxquantity);
            Controls.Add(txtboxaddress);
            Controls.Add(txtboxcontact);
            Controls.Add(txtboxdeleteorupdate);
            Controls.Add(lblId);
            Controls.Add(btnback);
            Controls.Add(btnviewall);
            Controls.Add(btndelete);
            Controls.Add(btnupdate);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(txtboxitemname);
            Controls.Add(txtboxcustomername);
            Controls.Add(lblquantity);
            Controls.Add(lblitemname);
            Controls.Add(lblcontact);
            Controls.Add(lblcustomername);
            Controls.Add(label1);
            ForeColor = SystemColors.ControlText;
            Name = "OrderForm";
            Text = "OrderForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblcustomername;
        private Label lblcontact;
        private Label lblitemname;
        private Label lblquantity;
        private TextBox txtboxcustomername;
        private TextBox txtboxitemname;
        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnupdate;
        private Button btndelete;
        private Button btnviewall;
        private Button btnback;
        private Label lblId;
        private TextBox txtboxdeleteorupdate;
        private TextBox txtboxcontact;
        private TextBox txtboxquantity;
        private TextBox txtboxitemprice;
        private TextBox txtboxaddress;
        private Label lbladdress;
        private Label lblsaleprice;
        private Button btncheckorder;
    }
}