﻿namespace desktopapplication.Product
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            txtboxId = new TextBox();
            lblId = new Label();
            btnViewAllProduct = new Button();
            btnUpdateProduct = new Button();
            btnDeleteProduct = new Button();
            btnAddProduct = new Button();
            dataGridView1 = new DataGridView();
            txtboxSaleprice = new TextBox();
            txtboxPurchaseprice = new TextBox();
            txtboxDescription = new TextBox();
            txtboxProductName = new TextBox();
            lblSaleprice = new Label();
            lblPurchaseprice = new Label();
            lbldescription = new Label();
            lblProductName = new Label();
            lblProductTitle = new Label();
            lbldiscount = new Label();
            txtboxDiscountProduct = new TextBox();
            btncheckproducts = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(794, 574);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 35;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // txtboxId
            // 
            txtboxId.Location = new Point(418, 462);
            txtboxId.Name = "txtboxId";
            txtboxId.Size = new Size(234, 31);
            txtboxId.TabIndex = 33;
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblId.Location = new Point(211, 462);
            lblId.Name = "lblId";
            lblId.Size = new Size(201, 28);
            lblId.TabIndex = 32;
            lblId.Text = "Id(delete or update)";
            lblId.Click += lblId_Click;
            // 
            // btnViewAllProduct
            // 
            btnViewAllProduct.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnViewAllProduct.Location = new Point(657, 574);
            btnViewAllProduct.Name = "btnViewAllProduct";
            btnViewAllProduct.Size = new Size(112, 34);
            btnViewAllProduct.TabIndex = 31;
            btnViewAllProduct.Text = "View All";
            btnViewAllProduct.UseVisualStyleBackColor = true;
            btnViewAllProduct.Click += btnViewAllProduct_Click;
            // 
            // btnUpdateProduct
            // 
            btnUpdateProduct.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdateProduct.Location = new Point(517, 574);
            btnUpdateProduct.Name = "btnUpdateProduct";
            btnUpdateProduct.Size = new Size(112, 34);
            btnUpdateProduct.TabIndex = 30;
            btnUpdateProduct.Text = "Update";
            btnUpdateProduct.UseVisualStyleBackColor = true;
            btnUpdateProduct.Click += btnUpdateProduct_Click;
            // 
            // btnDeleteProduct
            // 
            btnDeleteProduct.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeleteProduct.Location = new Point(383, 574);
            btnDeleteProduct.Name = "btnDeleteProduct";
            btnDeleteProduct.Size = new Size(112, 34);
            btnDeleteProduct.TabIndex = 29;
            btnDeleteProduct.Text = "Delete";
            btnDeleteProduct.UseVisualStyleBackColor = true;
            btnDeleteProduct.Click += btnDeleteProduct_Click;
            // 
            // btnAddProduct
            // 
            btnAddProduct.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddProduct.Location = new Point(248, 574);
            btnAddProduct.Name = "btnAddProduct";
            btnAddProduct.Size = new Size(112, 34);
            btnAddProduct.TabIndex = 28;
            btnAddProduct.Text = "Add";
            btnAddProduct.UseVisualStyleBackColor = true;
            btnAddProduct.Click += btnAddProduct_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(702, 247);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(360, 225);
            dataGridView1.TabIndex = 27;
            // 
            // txtboxSaleprice
            // 
            txtboxSaleprice.Location = new Point(418, 351);
            txtboxSaleprice.Name = "txtboxSaleprice";
            txtboxSaleprice.Size = new Size(234, 31);
            txtboxSaleprice.TabIndex = 26;
            // 
            // txtboxPurchaseprice
            // 
            txtboxPurchaseprice.Location = new Point(418, 293);
            txtboxPurchaseprice.Name = "txtboxPurchaseprice";
            txtboxPurchaseprice.Size = new Size(234, 31);
            txtboxPurchaseprice.TabIndex = 25;
            // 
            // txtboxDescription
            // 
            txtboxDescription.Location = new Point(418, 227);
            txtboxDescription.Name = "txtboxDescription";
            txtboxDescription.Size = new Size(234, 31);
            txtboxDescription.TabIndex = 24;
            // 
            // txtboxProductName
            // 
            txtboxProductName.Location = new Point(418, 171);
            txtboxProductName.Name = "txtboxProductName";
            txtboxProductName.Size = new Size(234, 31);
            txtboxProductName.TabIndex = 23;
            txtboxProductName.TextChanged += txtboxCustomerName_TextChanged;
            // 
            // lblSaleprice
            // 
            lblSaleprice.AutoSize = true;
            lblSaleprice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblSaleprice.Location = new Point(218, 354);
            lblSaleprice.Name = "lblSaleprice";
            lblSaleprice.Size = new Size(94, 25);
            lblSaleprice.TabIndex = 22;
            lblSaleprice.Text = "Sale Price";
            // 
            // lblPurchaseprice
            // 
            lblPurchaseprice.AutoSize = true;
            lblPurchaseprice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPurchaseprice.Location = new Point(218, 293);
            lblPurchaseprice.Name = "lblPurchaseprice";
            lblPurchaseprice.Size = new Size(136, 25);
            lblPurchaseprice.TabIndex = 21;
            lblPurchaseprice.Text = "Purchase Price";
            // 
            // lbldescription
            // 
            lbldescription.AutoSize = true;
            lbldescription.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbldescription.Location = new Point(218, 233);
            lbldescription.Name = "lbldescription";
            lbldescription.Size = new Size(109, 25);
            lbldescription.TabIndex = 20;
            lbldescription.Text = "Description";
            // 
            // lblProductName
            // 
            lblProductName.AutoSize = true;
            lblProductName.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductName.Location = new Point(218, 171);
            lblProductName.Name = "lblProductName";
            lblProductName.Size = new Size(140, 25);
            lblProductName.TabIndex = 19;
            lblProductName.Text = "Product Name";
            // 
            // lblProductTitle
            // 
            lblProductTitle.AutoSize = true;
            lblProductTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductTitle.Location = new Point(310, 88);
            lblProductTitle.Name = "lblProductTitle";
            lblProductTitle.Size = new Size(407, 32);
            lblProductTitle.TabIndex = 18;
            lblProductTitle.Text = "PRODUCT MANAGEMENT SYSTEM";
            // 
            // lbldiscount
            // 
            lbldiscount.AutoSize = true;
            lbldiscount.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbldiscount.Location = new Point(218, 415);
            lbldiscount.Name = "lbldiscount";
            lbldiscount.Size = new Size(87, 25);
            lbldiscount.TabIndex = 36;
            lbldiscount.Text = "Discount";
            // 
            // txtboxDiscountProduct
            // 
            txtboxDiscountProduct.Location = new Point(418, 409);
            txtboxDiscountProduct.Name = "txtboxDiscountProduct";
            txtboxDiscountProduct.Size = new Size(234, 31);
            txtboxDiscountProduct.TabIndex = 37;
            // 
            // btncheckproducts
            // 
            btncheckproducts.Location = new Point(757, 169);
            btncheckproducts.Name = "btncheckproducts";
            btncheckproducts.Size = new Size(224, 44);
            btncheckproducts.TabIndex = 38;
            btncheckproducts.Text = "Check Products";
            btncheckproducts.UseVisualStyleBackColor = true;
            btncheckproducts.Click += btncheckproducts_Click;
            // 
            // ProductForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1189, 720);
            Controls.Add(btncheckproducts);
            Controls.Add(txtboxDiscountProduct);
            Controls.Add(lbldiscount);
            Controls.Add(btnback);
            Controls.Add(txtboxId);
            Controls.Add(lblId);
            Controls.Add(btnViewAllProduct);
            Controls.Add(btnUpdateProduct);
            Controls.Add(btnDeleteProduct);
            Controls.Add(btnAddProduct);
            Controls.Add(dataGridView1);
            Controls.Add(txtboxSaleprice);
            Controls.Add(txtboxPurchaseprice);
            Controls.Add(txtboxDescription);
            Controls.Add(txtboxProductName);
            Controls.Add(lblSaleprice);
            Controls.Add(lblPurchaseprice);
            Controls.Add(lbldescription);
            Controls.Add(lblProductName);
            Controls.Add(lblProductTitle);
            Name = "ProductForm";
            Text = "ProductForm";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private TextBox txtboxId;
        private Label lblId;
        private Button btnViewAllProduct;
        private Button btnUpdateProduct;
        private Button btnDeleteProduct;
        private Button btnAddProduct;
        private DataGridView dataGridView1;
        private TextBox txtboxSaleprice;
        private TextBox txtboxPurchaseprice;
        private TextBox txtboxDescription;
        private TextBox txtboxProductName;
        private Label lblSaleprice;
        private Label lblPurchaseprice;
        private Label lbldescription;
        private Label lblProductName;
        private Label lblProductTitle;
        private Label lbldiscount;
        private TextBox txtboxDiscountProduct;
        private Button btncheckproducts;
    }
}