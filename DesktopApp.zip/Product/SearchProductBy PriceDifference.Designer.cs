﻿namespace desktopapplication.Product
{
    partial class SearchProductBy_PriceDifference
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBoxMinprice = new TextBox();
            lblProductMinPrice = new Label();
            btnback = new Button();
            btnsearchpricedifference = new Button();
            txtboxMaxprice = new TextBox();
            dataGridView1 = new DataGridView();
            lblProductMaxPrice = new Label();
            ProductPricerangeTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // txtBoxMinprice
            // 
            txtBoxMinprice.Location = new Point(529, 238);
            txtBoxMinprice.Name = "txtBoxMinprice";
            txtBoxMinprice.Size = new Size(324, 31);
            txtBoxMinprice.TabIndex = 27;
            // 
            // lblProductMinPrice
            // 
            lblProductMinPrice.AutoSize = true;
            lblProductMinPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductMinPrice.Location = new Point(165, 248);
            lblProductMinPrice.Name = "lblProductMinPrice";
            lblProductMinPrice.Size = new Size(215, 25);
            lblProductMinPrice.TabIndex = 26;
            lblProductMinPrice.Text = "MinPrice of the Product";
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(165, 537);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 25;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchpricedifference
            // 
            btnsearchpricedifference.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchpricedifference.Location = new Point(165, 356);
            btnsearchpricedifference.Name = "btnsearchpricedifference";
            btnsearchpricedifference.Size = new Size(190, 54);
            btnsearchpricedifference.TabIndex = 24;
            btnsearchpricedifference.Text = "Search Difference";
            btnsearchpricedifference.UseVisualStyleBackColor = true;
            btnsearchpricedifference.Click += btnsearchpricedifference_Click;
            // 
            // txtboxMaxprice
            // 
            txtboxMaxprice.Location = new Point(529, 173);
            txtboxMaxprice.Name = "txtboxMaxprice";
            txtboxMaxprice.Size = new Size(324, 31);
            txtboxMaxprice.TabIndex = 23;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(468, 316);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(495, 305);
            dataGridView1.TabIndex = 22;
            // 
            // lblProductMaxPrice
            // 
            lblProductMaxPrice.AutoSize = true;
            lblProductMaxPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductMaxPrice.Location = new Point(165, 173);
            lblProductMaxPrice.Name = "lblProductMaxPrice";
            lblProductMaxPrice.Size = new Size(219, 75);
            lblProductMaxPrice.TabIndex = 21;
            lblProductMaxPrice.Text = "MaxPrice of the Product\r\n\r\n\r\n";
            // 
            // ProductPricerangeTitle
            // 
            ProductPricerangeTitle.AutoSize = true;
            ProductPricerangeTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductPricerangeTitle.Location = new Point(319, 59);
            ProductPricerangeTitle.Name = "ProductPricerangeTitle";
            ProductPricerangeTitle.Size = new Size(603, 48);
            ProductPricerangeTitle.TabIndex = 20;
            ProductPricerangeTitle.Text = "Search Product By Price Difference";
            // 
            // SearchProductBy_PriceDifference
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1129, 680);
            Controls.Add(txtBoxMinprice);
            Controls.Add(lblProductMinPrice);
            Controls.Add(btnback);
            Controls.Add(btnsearchpricedifference);
            Controls.Add(txtboxMaxprice);
            Controls.Add(dataGridView1);
            Controls.Add(lblProductMaxPrice);
            Controls.Add(ProductPricerangeTitle);
            Name = "SearchProductBy_PriceDifference";
            Text = "SearchProductBy_PriceDifference";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBoxMinprice;
        private Label lblProductMinPrice;
        private Button btnback;
        private Button btnsearchpricedifference;
        private TextBox txtboxMaxprice;
        private DataGridView dataGridView1;
        private Label lblProductMaxPrice;
        private Label ProductPricerangeTitle;
    }
}