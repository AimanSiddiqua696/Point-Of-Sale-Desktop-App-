﻿namespace desktopapplication.Product
{
    partial class SearchProductBySubString
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchsubstring = new Button();
            txtboxSubString = new TextBox();
            dataGridView1 = new DataGridView();
            lblProductPrice = new Label();
            ProductsubstringTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(148, 611);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 23;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchsubstring
            // 
            btnsearchsubstring.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchsubstring.Location = new Point(148, 264);
            btnsearchsubstring.Name = "btnsearchsubstring";
            btnsearchsubstring.Size = new Size(193, 34);
            btnsearchsubstring.TabIndex = 22;
            btnsearchsubstring.Text = "Search SubString";
            btnsearchsubstring.UseVisualStyleBackColor = true;
            btnsearchsubstring.Click += btnsearchsubstring_Click;
            // 
            // txtboxSubString
            // 
            txtboxSubString.Location = new Point(512, 167);
            txtboxSubString.Name = "txtboxSubString";
            txtboxSubString.Size = new Size(324, 31);
            txtboxSubString.TabIndex = 21;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(432, 234);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(568, 399);
            dataGridView1.TabIndex = 20;
            // 
            // lblProductPrice
            // 
            lblProductPrice.AutoSize = true;
            lblProductPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductPrice.Location = new Point(148, 167);
            lblProductPrice.Name = "lblProductPrice";
            lblProductPrice.Size = new Size(223, 75);
            lblProductPrice.TabIndex = 19;
            lblProductPrice.Text = "SubString of the Product\r\n\r\n\r\n";
            lblProductPrice.Click += lblProductPrice_Click;
            // 
            // ProductsubstringTitle
            // 
            ProductsubstringTitle.AutoSize = true;
            ProductsubstringTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductsubstringTitle.Location = new Point(335, 62);
            ProductsubstringTitle.Name = "ProductsubstringTitle";
            ProductsubstringTitle.Size = new Size(501, 48);
            ProductsubstringTitle.TabIndex = 18;
            ProductsubstringTitle.Text = "Search Product By SubString";
            // 
            // SearchProductBySubString
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1148, 707);
            Controls.Add(btnback);
            Controls.Add(btnsearchsubstring);
            Controls.Add(txtboxSubString);
            Controls.Add(dataGridView1);
            Controls.Add(lblProductPrice);
            Controls.Add(ProductsubstringTitle);
            Name = "SearchProductBySubString";
            Text = "SearchProductBySubString";
            Load += SearchProductBySubString_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchsubstring;
        private TextBox txtboxSubString;
        private DataGridView dataGridView1;
        private Label lblProductPrice;
        private Label ProductsubstringTitle;
    }
}