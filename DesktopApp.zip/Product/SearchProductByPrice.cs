﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{

    public partial class SearchProductByPrice : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchProductByPrice()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale point = new PointOfSale();
            point.Show();
        }

        private void btnsearchprice_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1 WHERE saleprice = @saleprice;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@saleprice", txtboxproductprice.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
