﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{
    public partial class SearchByName : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchByName()
        {
            InitializeComponent();
        }

        private void lblCustomername_Click(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale sale = new PointOfSale();
            sale.Show();
        }

        private void btnsearchname_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1 WHERE name = @name;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@name", txtboxproductname.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
