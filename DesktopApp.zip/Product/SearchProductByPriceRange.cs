﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace desktopapplication.Product
{
    public partial class SearchProductByPriceRange : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchProductByPriceRange()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale point = new PointOfSale();
            point.Show();
        }

        private void btnsearchpricerange_Click(object sender, EventArgs e)
        {
             int maxprice = Convert.ToInt32(txtboxMaxprice.Text);
            int minprice = Convert.ToInt32(txtBoxMinprice.Text);
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1 WHERE saleprice BETWEEN @minprice AND  @maxprice;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@minprice", minprice);
                sqlDa.SelectCommand.Parameters.AddWithValue("@maxprice", maxprice);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
