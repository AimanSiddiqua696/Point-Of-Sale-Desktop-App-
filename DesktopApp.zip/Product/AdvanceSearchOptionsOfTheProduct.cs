﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{
    public partial class AdvanceSearchOptionsOfTheProduct : Form
    {
        public AdvanceSearchOptionsOfTheProduct()
        {
            InitializeComponent();
        }

        private void btnSearchbyname_Click(object sender, EventArgs e)
        {
            SearchByName name = new SearchByName();
            name.Show();

        }

        private void btnSearchbyprice_Click(object sender, EventArgs e)
        {
            SearchProductByPrice price = new SearchProductByPrice();
            price.Show();
        }

        private void btnSearchbyRange_Click(object sender, EventArgs e)
        {
            SearchProductByPriceRange range = new SearchProductByPriceRange();
            range.Show();

        }

        private void btnSearchbypricedifference_Click(object sender, EventArgs e)
        {
            SearchProductBy_PriceDifference difference = new SearchProductBy_PriceDifference();
            difference.Show();
        }

        private void btnSearchBySubstring_Click(object sender, EventArgs e)
        {
            SearchProductBySubString substring = new SearchProductBySubString();
            substring.Show(); 
        }
    }
}
