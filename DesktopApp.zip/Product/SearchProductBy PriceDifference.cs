﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{
    public partial class SearchProductBy_PriceDifference : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchProductBy_PriceDifference()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale point = new PointOfSale();
            point.Show();
        }

        private void btnsearchpricedifference_Click(object sender, EventArgs e)
        {
            int maxprice = Convert.ToInt32(txtboxMaxprice.Text);
            int minprice = Convert.ToInt32(txtBoxMinprice.Text);
            int difference = maxprice - minprice;
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1 WHERE saleprice > @difference;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@difference", difference);
                
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }

        }
    }
}
//SqlDataAdapter sqlDa = new SqlDataAdapter(
//    "SELECT * FROM PRODUCT1 
//     WHERE price BETWEEN @minprice AND @maxprice
//     AND productName LIKE '%' + @name + '%'",
//    sqlconn);

//sqlDa.SelectCommand.Parameters.AddWithValue("@name", txtboxproduct.Text);


