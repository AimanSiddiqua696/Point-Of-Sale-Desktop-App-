﻿namespace desktopapplication.Product
{
    partial class AdvanceSearchOptionsOfTheProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnBack = new Button();
            btnSearchBySubstring = new Button();
            btnSearchbypricedifference = new Button();
            btnSearchbyRange = new Button();
            btnSearchbyprice = new Button();
            btnSearchbyname = new Button();
            AdvanceFeaturesTitle = new Label();
            SuspendLayout();
            // 
            // btnBack
            // 
            btnBack.BackColor = SystemColors.GradientActiveCaption;
            btnBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.DarkRed;
            btnBack.Location = new Point(443, 650);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(114, 44);
            btnBack.TabIndex = 22;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            // 
            // btnSearchBySubstring
            // 
            btnSearchBySubstring.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchBySubstring.Location = new Point(344, 547);
            btnSearchBySubstring.Name = "btnSearchBySubstring";
            btnSearchBySubstring.Size = new Size(325, 71);
            btnSearchBySubstring.TabIndex = 21;
            btnSearchBySubstring.Text = "Search By SubString";
            btnSearchBySubstring.UseVisualStyleBackColor = true;
            btnSearchBySubstring.Click += btnSearchBySubstring_Click;
            // 
            // btnSearchbypricedifference
            // 
            btnSearchbypricedifference.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbypricedifference.Location = new Point(344, 423);
            btnSearchbypricedifference.Name = "btnSearchbypricedifference";
            btnSearchbypricedifference.Size = new Size(325, 88);
            btnSearchbypricedifference.TabIndex = 20;
            btnSearchbypricedifference.Text = "Search By price Difference";
            btnSearchbypricedifference.UseVisualStyleBackColor = true;
            btnSearchbypricedifference.Click += btnSearchbypricedifference_Click;
            // 
            // btnSearchbyRange
            // 
            btnSearchbyRange.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyRange.Location = new Point(344, 301);
            btnSearchbyRange.Name = "btnSearchbyRange";
            btnSearchbyRange.Size = new Size(325, 83);
            btnSearchbyRange.TabIndex = 19;
            btnSearchbyRange.Text = "Search By Range";
            btnSearchbyRange.UseVisualStyleBackColor = true;
            btnSearchbyRange.Click += btnSearchbyRange_Click;
            // 
            // btnSearchbyprice
            // 
            btnSearchbyprice.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyprice.Location = new Point(344, 188);
            btnSearchbyprice.Name = "btnSearchbyprice";
            btnSearchbyprice.Size = new Size(325, 76);
            btnSearchbyprice.TabIndex = 18;
            btnSearchbyprice.Text = "Search By Price";
            btnSearchbyprice.UseVisualStyleBackColor = true;
            btnSearchbyprice.Click += btnSearchbyprice_Click;
            // 
            // btnSearchbyname
            // 
            btnSearchbyname.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyname.Location = new Point(344, 87);
            btnSearchbyname.Name = "btnSearchbyname";
            btnSearchbyname.Size = new Size(325, 72);
            btnSearchbyname.TabIndex = 17;
            btnSearchbyname.Text = "Search By Name";
            btnSearchbyname.UseVisualStyleBackColor = true;
            btnSearchbyname.Click += btnSearchbyname_Click;
            // 
            // AdvanceFeaturesTitle
            // 
            AdvanceFeaturesTitle.AutoSize = true;
            AdvanceFeaturesTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AdvanceFeaturesTitle.Location = new Point(207, 10);
            AdvanceFeaturesTitle.Name = "AdvanceFeaturesTitle";
            AdvanceFeaturesTitle.Size = new Size(597, 48);
            AdvanceFeaturesTitle.TabIndex = 16;
            AdvanceFeaturesTitle.Text = "ADVANCE FEATURES IN PRODUCT";
            // 
            // AdvanceSearchOptionsOfTheProduct
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1035, 704);
            Controls.Add(btnBack);
            Controls.Add(btnSearchBySubstring);
            Controls.Add(btnSearchbypricedifference);
            Controls.Add(btnSearchbyRange);
            Controls.Add(btnSearchbyprice);
            Controls.Add(btnSearchbyname);
            Controls.Add(AdvanceFeaturesTitle);
            Name = "AdvanceSearchOptionsOfTheProduct";
            Text = "AdvanceSearchOptionsOfTheProduct";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnBack;
        private Button btnSearchBySubstring;
        private Button btnSearchbypricedifference;
        private Button btnSearchbyRange;
        private Button btnSearchbyprice;
        private Button btnSearchbyname;
        private Label AdvanceFeaturesTitle;
    }
}