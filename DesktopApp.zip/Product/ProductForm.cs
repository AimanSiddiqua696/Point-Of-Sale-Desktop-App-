﻿using desktopapplication.Customer;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{

    public partial class ProductForm : Form

    {
        string DbConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        ProductRepoDB repo = new ProductRepoDB();
        public ProductForm()
        {
            InitializeComponent();
        }

        private void lblId_Click(object sender, EventArgs e)
        {

        }

        private void btnViewAllProduct_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(DbConnection))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1", sqlCon);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale ps = new PointOfSale();
            ps.Show();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {

            string name = txtboxProductName.Text;
            string description = txtboxDescription.Text;
            int purchaseprice = Convert.ToInt32(txtboxPurchaseprice.Text);
            int saleprice = Convert.ToInt32(txtboxSaleprice.Text);
            int discount = Convert.ToInt32(txtboxDiscountProduct.Text);

            ProductModel customer = new ProductModel(name, description, purchaseprice, saleprice, discount);

            repo.Create(customer);
        }

        private void txtboxCustomerName_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtboxId.Text);
            repo.Delete(id);
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtboxId.Text);
            string name = txtboxProductName.Text;
            string description = txtboxDescription.Text;
            int purchaseprice = int.Parse(txtboxPurchaseprice.Text);
            int saleprice = int.Parse(txtboxSaleprice.Text);
            int discount = Convert.ToInt32(txtboxDiscountProduct.Text);
            ProductModel product = new ProductModel(id, name, description, purchaseprice, saleprice, discount);
            repo.Update(product);

        }

        private void btncheckproducts_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(DbConnection))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1", sqlCon);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}
