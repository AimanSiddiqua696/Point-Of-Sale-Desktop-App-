﻿namespace desktopapplication.Product
{
    partial class SearchProductByPrice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchprice = new Button();
            txtboxproductprice = new TextBox();
            dataGridView1 = new DataGridView();
            lblProductPrice = new Label();
            ProductNameTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(93, 584);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 17;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchprice
            // 
            btnsearchprice.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchprice.Location = new Point(93, 237);
            btnsearchprice.Name = "btnsearchprice";
            btnsearchprice.Size = new Size(193, 34);
            btnsearchprice.TabIndex = 16;
            btnsearchprice.Text = "Search Price";
            btnsearchprice.UseVisualStyleBackColor = true;
            btnsearchprice.Click += btnsearchprice_Click;
            // 
            // txtboxproductprice
            // 
            txtboxproductprice.Location = new Point(457, 140);
            txtboxproductprice.Name = "txtboxproductprice";
            txtboxproductprice.Size = new Size(324, 31);
            txtboxproductprice.TabIndex = 15;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(377, 207);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(568, 399);
            dataGridView1.TabIndex = 14;
            // 
            // lblProductPrice
            // 
            lblProductPrice.AutoSize = true;
            lblProductPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductPrice.Location = new Point(93, 140);
            lblProductPrice.Name = "lblProductPrice";
            lblProductPrice.Size = new Size(182, 75);
            lblProductPrice.TabIndex = 13;
            lblProductPrice.Text = "Price of the Product\r\n\r\n\r\n";
            // 
            // ProductNameTitle
            // 
            ProductNameTitle.AutoSize = true;
            ProductNameTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductNameTitle.Location = new Point(280, 35);
            ProductNameTitle.Name = "ProductNameTitle";
            ProductNameTitle.Size = new Size(418, 48);
            ProductNameTitle.TabIndex = 12;
            ProductNameTitle.Text = "Search Product By Price";
            // 
            // SearchProductByPrice
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1038, 653);
            Controls.Add(btnback);
            Controls.Add(btnsearchprice);
            Controls.Add(txtboxproductprice);
            Controls.Add(dataGridView1);
            Controls.Add(lblProductPrice);
            Controls.Add(ProductNameTitle);
            Name = "SearchProductByPrice";
            Text = "SearchProductByPrice";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchprice;
        private TextBox txtboxproductprice;
        private DataGridView dataGridView1;
        private Label lblProductPrice;
        private Label ProductNameTitle;
    }
}