﻿namespace desktopapplication.Product
{
    partial class SearchByName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchname = new Button();
            txtboxproductname = new TextBox();
            dataGridView1 = new DataGridView();
            lblCustomername = new Label();
            ProductNameTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(91, 581);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 11;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchname
            // 
            btnsearchname.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchname.Location = new Point(91, 234);
            btnsearchname.Name = "btnsearchname";
            btnsearchname.Size = new Size(193, 34);
            btnsearchname.TabIndex = 10;
            btnsearchname.Text = "Search Name";
            btnsearchname.UseVisualStyleBackColor = true;
            btnsearchname.Click += btnsearchname_Click;
            // 
            // txtboxproductname
            // 
            txtboxproductname.Location = new Point(455, 137);
            txtboxproductname.Name = "txtboxproductname";
            txtboxproductname.Size = new Size(324, 31);
            txtboxproductname.TabIndex = 9;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(375, 204);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(568, 399);
            dataGridView1.TabIndex = 8;
            // 
            // lblCustomername
            // 
            lblCustomername.AutoSize = true;
            lblCustomername.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomername.Location = new Point(91, 137);
            lblCustomername.Name = "lblCustomername";
            lblCustomername.Size = new Size(190, 75);
            lblCustomername.TabIndex = 7;
            lblCustomername.Text = "Name of the Product\r\n\r\n\r\n";
            lblCustomername.Click += lblCustomername_Click;
            // 
            // ProductNameTitle
            // 
            ProductNameTitle.AutoSize = true;
            ProductNameTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductNameTitle.Location = new Point(278, 32);
            ProductNameTitle.Name = "ProductNameTitle";
            ProductNameTitle.Size = new Size(435, 48);
            ProductNameTitle.TabIndex = 6;
            ProductNameTitle.Text = "Search Product By Name";
            // 
            // SearchByName
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1034, 646);
            Controls.Add(btnback);
            Controls.Add(btnsearchname);
            Controls.Add(txtboxproductname);
            Controls.Add(dataGridView1);
            Controls.Add(lblCustomername);
            Controls.Add(ProductNameTitle);
            Name = "SearchByName";
            Text = "SearchByName";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchname;
        private TextBox txtboxproductname;
        private DataGridView dataGridView1;
        private Label lblCustomername;
        private Label ProductNameTitle;
    }
}