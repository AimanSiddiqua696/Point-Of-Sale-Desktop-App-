﻿namespace desktopapplication.Product
{
    partial class SearchProductByPriceRange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchpricerange = new Button();
            txtboxMaxprice = new TextBox();
            dataGridView1 = new DataGridView();
            lblProductMaxPrice = new Label();
            ProductPricerangeTitle = new Label();
            lblProductMinPrice = new Label();
            txtBoxMinprice = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(117, 515);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 17;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchpricerange
            // 
            btnsearchpricerange.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchpricerange.Location = new Point(117, 334);
            btnsearchpricerange.Name = "btnsearchpricerange";
            btnsearchpricerange.Size = new Size(190, 54);
            btnsearchpricerange.TabIndex = 16;
            btnsearchpricerange.Text = "Search Range";
            btnsearchpricerange.UseVisualStyleBackColor = true;
            btnsearchpricerange.Click += btnsearchpricerange_Click;
            // 
            // txtboxMaxprice
            // 
            txtboxMaxprice.Location = new Point(481, 151);
            txtboxMaxprice.Name = "txtboxMaxprice";
            txtboxMaxprice.Size = new Size(324, 31);
            txtboxMaxprice.TabIndex = 15;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(420, 294);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(495, 305);
            dataGridView1.TabIndex = 14;
            // 
            // lblProductMaxPrice
            // 
            lblProductMaxPrice.AutoSize = true;
            lblProductMaxPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductMaxPrice.Location = new Point(117, 151);
            lblProductMaxPrice.Name = "lblProductMaxPrice";
            lblProductMaxPrice.Size = new Size(219, 75);
            lblProductMaxPrice.TabIndex = 13;
            lblProductMaxPrice.Text = "MaxPrice of the Product\r\n\r\n\r\n";
            // 
            // ProductPricerangeTitle
            // 
            ProductPricerangeTitle.AutoSize = true;
            ProductPricerangeTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ProductPricerangeTitle.Location = new Point(271, 37);
            ProductPricerangeTitle.Name = "ProductPricerangeTitle";
            ProductPricerangeTitle.Size = new Size(534, 48);
            ProductPricerangeTitle.TabIndex = 12;
            ProductPricerangeTitle.Text = "Search Product By Price Range";
            // 
            // lblProductMinPrice
            // 
            lblProductMinPrice.AutoSize = true;
            lblProductMinPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblProductMinPrice.Location = new Point(117, 226);
            lblProductMinPrice.Name = "lblProductMinPrice";
            lblProductMinPrice.Size = new Size(215, 25);
            lblProductMinPrice.TabIndex = 18;
            lblProductMinPrice.Text = "MinPrice of the Product";
            // 
            // txtBoxMinprice
            // 
            txtBoxMinprice.Location = new Point(481, 216);
            txtBoxMinprice.Name = "txtBoxMinprice";
            txtBoxMinprice.Size = new Size(324, 31);
            txtBoxMinprice.TabIndex = 19;
            // 
            // SearchProductByPriceRange
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1111, 698);
            Controls.Add(txtBoxMinprice);
            Controls.Add(lblProductMinPrice);
            Controls.Add(btnback);
            Controls.Add(btnsearchpricerange);
            Controls.Add(txtboxMaxprice);
            Controls.Add(dataGridView1);
            Controls.Add(lblProductMaxPrice);
            Controls.Add(ProductPricerangeTitle);
            Name = "SearchProductByPriceRange";
            Text = "SearchProductByPriceRange";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchpricerange;
        private TextBox txtboxMaxprice;
        private DataGridView dataGridView1;
        private Label lblProductMaxPrice;
        private Label ProductPricerangeTitle;
        private Label lblProductMinPrice;
        private TextBox txtBoxMinprice;
    }
}