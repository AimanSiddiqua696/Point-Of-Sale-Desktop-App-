﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication.Product
{
    public partial class SearchProductBySubString : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchProductBySubString()
        {
            InitializeComponent();
        }

        private void lblProductPrice_Click(object sender, EventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale point = new PointOfSale();
            point.Show();
        }

        private void btnsearchsubstring_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlconn = new SqlConnection(DBConnection))

            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM PRODUCT1 WHERE name LIKE'%'+ @letter +'%';", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@letter", txtboxSubString.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void SearchProductBySubString_Load(object sender, EventArgs e)
        {

        }
    }
}
