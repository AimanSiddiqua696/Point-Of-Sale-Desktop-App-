﻿namespace desktopapplication
{
    partial class SearchCustomerByAge
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchage = new Button();
            txtboxcustomerage = new TextBox();
            AgedataGridView1 = new DataGridView();
            lblCustomerage = new Label();
            CustomerAgeTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)AgedataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(126, 601);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 11;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchage
            // 
            btnsearchage.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchage.Location = new Point(126, 254);
            btnsearchage.Name = "btnsearchage";
            btnsearchage.Size = new Size(193, 34);
            btnsearchage.TabIndex = 10;
            btnsearchage.Text = "SearchAge";
            btnsearchage.UseVisualStyleBackColor = true;
            btnsearchage.Click += btnsearchage_Click;
            // 
            // txtboxcustomerage
            // 
            txtboxcustomerage.Location = new Point(490, 157);
            txtboxcustomerage.Name = "txtboxcustomerage";
            txtboxcustomerage.Size = new Size(324, 31);
            txtboxcustomerage.TabIndex = 9;
            // 
            // AgedataGridView1
            // 
            AgedataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AgedataGridView1.Location = new Point(410, 224);
            AgedataGridView1.Name = "AgedataGridView1";
            AgedataGridView1.RowHeadersWidth = 62;
            AgedataGridView1.Size = new Size(568, 399);
            AgedataGridView1.TabIndex = 8;
            // 
            // lblCustomerage
            // 
            lblCustomerage.AutoSize = true;
            lblCustomerage.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerage.Location = new Point(126, 158);
            lblCustomerage.Name = "lblCustomerage";
            lblCustomerage.Size = new Size(227, 30);
            lblCustomerage.TabIndex = 7;
            lblCustomerage.Text = "Age of the Customer";
            // 
            // CustomerAgeTitle
            // 
            CustomerAgeTitle.AutoSize = true;
            CustomerAgeTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerAgeTitle.Location = new Point(313, 52);
            CustomerAgeTitle.Name = "CustomerAgeTitle";
            CustomerAgeTitle.Size = new Size(431, 48);
            CustomerAgeTitle.TabIndex = 6;
            CustomerAgeTitle.Text = "Search Customer By Age";
            // 
            // SearchCustomerByAge
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1105, 686);
            Controls.Add(btnback);
            Controls.Add(btnsearchage);
            Controls.Add(txtboxcustomerage);
            Controls.Add(AgedataGridView1);
            Controls.Add(lblCustomerage);
            Controls.Add(CustomerAgeTitle);
            Name = "SearchCustomerByAge";
            Text = "SearchCustomerByAge";
            ((System.ComponentModel.ISupportInitialize)AgedataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchage;
        private TextBox txtboxcustomerage;
        private DataGridView AgedataGridView1;
        private Label lblCustomerage;
        private Label CustomerAgeTitle;
    }
}