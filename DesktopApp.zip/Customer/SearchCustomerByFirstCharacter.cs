﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication
{
    public partial class SearchCustomerByFirstCharacter : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchCustomerByFirstCharacter()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale pos = new PointOfSale();
            pos.Show();

        }

        private void btnsearchCharacter_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))

            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1 WHERE cname LIKE @letter +'%';", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@letter", txtboxcustomeraddress.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                CharacterdataGridView1.DataSource = dt;
            }
        }
    }
}