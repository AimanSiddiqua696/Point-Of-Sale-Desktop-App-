﻿namespace desktopapplication
{
    partial class PointOfSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnCustomermanagementsystemtitle = new Button();
            button2 = new Button();
            btnordermanagementsystem = new Button();
            btnAdvanceproductfeatures = new Button();
            btncustomeradvancefeatures = new Button();
            ADVANCEFEATURES = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(341, 53);
            label1.Name = "label1";
            label1.Size = new Size(277, 48);
            label1.TabIndex = 0;
            label1.Text = "POINT OF SALE";
            // 
            // btnCustomermanagementsystemtitle
            // 
            btnCustomermanagementsystemtitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCustomermanagementsystemtitle.Location = new Point(163, 129);
            btnCustomermanagementsystemtitle.Name = "btnCustomermanagementsystemtitle";
            btnCustomermanagementsystemtitle.Size = new Size(629, 51);
            btnCustomermanagementsystemtitle.TabIndex = 1;
            btnCustomermanagementsystemtitle.Text = "CUSTOMER MANAGEMENT SYSTEM\r\n\r\n";
            btnCustomermanagementsystemtitle.UseVisualStyleBackColor = true;
            btnCustomermanagementsystemtitle.Click += btnCustomermanagementsystemtitle_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.Location = new Point(163, 215);
            button2.Name = "button2";
            button2.Size = new Size(621, 55);
            button2.TabIndex = 2;
            button2.Text = "PRODUCT MANAGEMENT SYSTEM";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // btnordermanagementsystem
            // 
            btnordermanagementsystem.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnordermanagementsystem.Location = new Point(163, 310);
            btnordermanagementsystem.Name = "btnordermanagementsystem";
            btnordermanagementsystem.Size = new Size(629, 59);
            btnordermanagementsystem.TabIndex = 3;
            btnordermanagementsystem.Text = "ORDER MANAGEMENT SYSTEM";
            btnordermanagementsystem.UseVisualStyleBackColor = true;
            btnordermanagementsystem.Click += btnordermanagementsystem_Click;
            // 
            // btnAdvanceproductfeatures
            // 
            btnAdvanceproductfeatures.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdvanceproductfeatures.Location = new Point(223, 579);
            btnAdvanceproductfeatures.Name = "btnAdvanceproductfeatures";
            btnAdvanceproductfeatures.Size = new Size(486, 63);
            btnAdvanceproductfeatures.TabIndex = 4;
            btnAdvanceproductfeatures.Text = "PRODUCT ADVANCE FEATURES";
            btnAdvanceproductfeatures.UseVisualStyleBackColor = true;
            btnAdvanceproductfeatures.Click += btnAdvanceproductfeatures_Click;
            // 
            // btncustomeradvancefeatures
            // 
            btncustomeradvancefeatures.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btncustomeradvancefeatures.Location = new Point(223, 485);
            btncustomeradvancefeatures.Name = "btncustomeradvancefeatures";
            btncustomeradvancefeatures.Size = new Size(495, 55);
            btncustomeradvancefeatures.TabIndex = 5;
            btncustomeradvancefeatures.Text = "CUSTOMER ADVANCE FEATURES";
            btncustomeradvancefeatures.UseVisualStyleBackColor = true;
            btncustomeradvancefeatures.Click += btncustomeradvancefeatures_Click;
            // 
            // ADVANCEFEATURES
            // 
            ADVANCEFEATURES.AutoSize = true;
            ADVANCEFEATURES.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ADVANCEFEATURES.Location = new Point(300, 407);
            ADVANCEFEATURES.Name = "ADVANCEFEATURES";
            ADVANCEFEATURES.Size = new Size(369, 48);
            ADVANCEFEATURES.TabIndex = 6;
            ADVANCEFEATURES.Text = "ADVANCE FEATURES";
            // 
            // PointOfSale
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1059, 669);
            Controls.Add(ADVANCEFEATURES);
            Controls.Add(btncustomeradvancefeatures);
            Controls.Add(btnAdvanceproductfeatures);
            Controls.Add(btnordermanagementsystem);
            Controls.Add(button2);
            Controls.Add(btnCustomermanagementsystemtitle);
            Controls.Add(label1);
            Name = "PointOfSale";
            Text = "PointOfSale";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnCustomermanagementsystemtitle;
        private Button button2;
        private Button btnordermanagementsystem;
        private Button btnAdvanceproductfeatures;
        private Button btncustomeradvancefeatures;
        private Label ADVANCEFEATURES;
    }
}