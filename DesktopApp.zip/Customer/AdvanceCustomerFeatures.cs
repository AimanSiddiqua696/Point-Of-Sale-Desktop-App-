﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication
{
    public partial class AdvanceCustomerFeatures : Form
    {
        public AdvanceCustomerFeatures()
        {
            InitializeComponent();
        }

        private void Name_Click(object sender, EventArgs e)
        {

        }

        private void btnSearchbyname_Click(object sender, EventArgs e)
        {
            SearchCustomerByName cbn = new SearchCustomerByName();
            cbn.Show();
        }

        private void AdvanceFeaturesTitle_Click(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            PointOfSale pos = new PointOfSale();
            pos.Show();
            this.Hide();
        }

        private void btnSearchbyAge_Click(object sender, EventArgs e)
        {
            SearchCustomerByAge cbn = new SearchCustomerByAge();
            cbn.Show();
        }

        private void btnSearchbyfirstchar_Click(object sender, EventArgs e)
        {

            SearchCustomerByFirstCharacter cbn = new SearchCustomerByFirstCharacter();
            cbn.Show();
        }

        private void btnSearchbyContact_Click(object sender, EventArgs e)
        {
            SearchCustomerByContact cbn = new SearchCustomerByContact();
            cbn.Show();
        }

        private void btnSearchByAddress_Click(object sender, EventArgs e)
        {
            SearchByAddress cbn = new SearchByAddress();
            cbn.Show();
        }

        private void AdvanceCustomerFeatures_Load(object sender, EventArgs e)
        {

        }
    }
}
//string customername = txtboxCustomerName.Text;
//string address = txtboxCustomerAddress.Text;
//int age = Convert.ToInt32(txtboxCustomerAge.Text);
//string phoneno = txtboxCustomerContact.Text;

//CustomerModel customer = new CustomerModel(customername, address, age, phoneno);

//repo.Create(customer);