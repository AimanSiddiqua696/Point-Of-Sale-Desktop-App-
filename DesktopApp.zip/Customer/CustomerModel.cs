﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desktopapplication.Customer
{
    internal class CustomerModel
    {
        public int id { get; set; }
        public string cname { get; set; }
        public string phonenumber { get; set; }
        public int age { get; set; }
        public string address { get; set; }
        //public List<ProductModel> products = new List<ProductModel>();

        public CustomerModel()
        {

        }
        public CustomerModel(string cname, string phonenumber, int age, string address)
        {
            this.cname = cname;
            this.phonenumber = phonenumber;
            this.age = age;
            this.address = address;
        }
        public CustomerModel(int id, string cname, string phonenumber, int age, string address)
        {
            this.id = id;
            this.cname = cname;
            this.phonenumber = phonenumber;
            this.age = age;
            this.address = address;
        }
        public void SetName(string cname)
        {
            this.cname = cname;
        }
        public string GetName()
        {
            return cname;
        }
        public void SetPhoneNumber(string phonenumber)
        {
            this.phonenumber = phonenumber;
        }
        public string GetPhoneNumber()
        {

            return phonenumber;
        }
        public void SetAge(int age)
        {
            this.age = age;
        }
        public int GetAge()
        {
            return age;
        }
        public void SetAddress(string address)
        {
            this.address = address;

        }
        public string GetAddress()
        {
            return address;

        }


        public override string ToString()
        {

            return $"{cname},{phonenumber},{age},{address}";
        }

    }


}

    
  