﻿namespace desktopapplication
{
    partial class AdvanceCustomerFeatures
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AdvanceFeaturesTitle = new Label();
            btnSearchbyname = new Button();
            btnSearchbyAge = new Button();
            lblFCharacter = new Label();
            btnSearchbyfirstchar = new Button();
            btnSearchbyContact = new Button();
            btnSearchByAddress = new Button();
            btnBack = new Button();
            SuspendLayout();
            // 
            // AdvanceFeaturesTitle
            // 
            AdvanceFeaturesTitle.AutoSize = true;
            AdvanceFeaturesTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            AdvanceFeaturesTitle.Location = new Point(193, 31);
            AdvanceFeaturesTitle.Name = "AdvanceFeaturesTitle";
            AdvanceFeaturesTitle.Size = new Size(620, 48);
            AdvanceFeaturesTitle.TabIndex = 1;
            AdvanceFeaturesTitle.Text = "ADVANCE FEATURES IN CUSTOMER";
            AdvanceFeaturesTitle.Click += AdvanceFeaturesTitle_Click;
            // 
            // btnSearchbyname
            // 
            btnSearchbyname.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyname.Location = new Point(330, 108);
            btnSearchbyname.Name = "btnSearchbyname";
            btnSearchbyname.Size = new Size(325, 72);
            btnSearchbyname.TabIndex = 4;
            btnSearchbyname.Text = "SearchByName";
            btnSearchbyname.UseVisualStyleBackColor = true;
            btnSearchbyname.Click += btnSearchbyname_Click;
            // 
            // btnSearchbyAge
            // 
            btnSearchbyAge.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyAge.Location = new Point(330, 209);
            btnSearchbyAge.Name = "btnSearchbyAge";
            btnSearchbyAge.Size = new Size(325, 76);
            btnSearchbyAge.TabIndex = 5;
            btnSearchbyAge.Text = "SearchByAge";
            btnSearchbyAge.UseVisualStyleBackColor = true;
            btnSearchbyAge.Click += btnSearchbyAge_Click;
            // 
            // lblFCharacter
            // 
            lblFCharacter.AutoSize = true;
            lblFCharacter.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblFCharacter.Location = new Point(16, 242);
            lblFCharacter.Name = "lblFCharacter";
            lblFCharacter.Size = new Size(0, 28);
            lblFCharacter.TabIndex = 8;
            // 
            // btnSearchbyfirstchar
            // 
            btnSearchbyfirstchar.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyfirstchar.Location = new Point(330, 322);
            btnSearchbyfirstchar.Name = "btnSearchbyfirstchar";
            btnSearchbyfirstchar.Size = new Size(325, 83);
            btnSearchbyfirstchar.TabIndex = 10;
            btnSearchbyfirstchar.Text = "SearchByFirstChar";
            btnSearchbyfirstchar.UseVisualStyleBackColor = true;
            btnSearchbyfirstchar.Click += btnSearchbyfirstchar_Click;
            // 
            // btnSearchbyContact
            // 
            btnSearchbyContact.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchbyContact.Location = new Point(330, 444);
            btnSearchbyContact.Name = "btnSearchbyContact";
            btnSearchbyContact.Size = new Size(325, 88);
            btnSearchbyContact.TabIndex = 11;
            btnSearchbyContact.Text = "SearchByContact";
            btnSearchbyContact.UseVisualStyleBackColor = true;
            btnSearchbyContact.Click += btnSearchbyContact_Click;
            // 
            // btnSearchByAddress
            // 
            btnSearchByAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSearchByAddress.Location = new Point(330, 568);
            btnSearchByAddress.Name = "btnSearchByAddress";
            btnSearchByAddress.Size = new Size(325, 71);
            btnSearchByAddress.TabIndex = 14;
            btnSearchByAddress.Text = "SearchByAddress";
            btnSearchByAddress.UseVisualStyleBackColor = true;
            btnSearchByAddress.Click += btnSearchByAddress_Click;
            // 
            // btnBack
            // 
            btnBack.BackColor = SystemColors.GradientActiveCaption;
            btnBack.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBack.ForeColor = Color.DarkRed;
            btnBack.Location = new Point(429, 671);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(114, 44);
            btnBack.TabIndex = 15;
            btnBack.Text = "Back";
            btnBack.UseVisualStyleBackColor = false;
            btnBack.Click += btnBack_Click;
            // 
            // AdvanceCustomerFeatures
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1069, 739);
            Controls.Add(btnBack);
            Controls.Add(btnSearchByAddress);
            Controls.Add(btnSearchbyContact);
            Controls.Add(btnSearchbyfirstchar);
            Controls.Add(lblFCharacter);
            Controls.Add(btnSearchbyAge);
            Controls.Add(btnSearchbyname);
            Controls.Add(AdvanceFeaturesTitle);
            Name = "AdvanceCustomerFeatures";
            Text = "AdvanceCustomerFeatures";
            Load += AdvanceCustomerFeatures_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label AdvanceFeaturesTitle;
        private Button btnSearchbyname;
        private Button btnSearchbyAge;
        private Label lblFCharacter;
        private Button btnSearchbyfirstchar;
        private Button btnSearchbyContact;
        private Button btnSearchByAddress;
        private Button btnBack;
    }
}