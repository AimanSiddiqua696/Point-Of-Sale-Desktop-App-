﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication
{
    public partial class SearchCustomerByName : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchCustomerByName()
        {
            InitializeComponent();
        }

        private void btnsearchname_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1 WHERE cname = @cname;", sqlconn);
               
                sqlDa.SelectCommand.Parameters.AddWithValue("@cname",  txtboxcustomername.Text );
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale pos = new PointOfSale();
            pos.Show();
            this.Hide();
        }
    }
}

