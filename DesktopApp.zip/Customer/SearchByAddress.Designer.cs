﻿namespace desktopapplication
{
    partial class SearchByAddress
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchAddress = new Button();
            txtboxcustomerAddress = new TextBox();
            AddressdataGridView1 = new DataGridView();
            lblCustomerAddress = new Label();
            CustomerAddressTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)AddressdataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(120, 620);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 11;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchAddress
            // 
            btnsearchAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchAddress.Location = new Point(41, 273);
            btnsearchAddress.Name = "btnsearchAddress";
            btnsearchAddress.Size = new Size(357, 34);
            btnsearchAddress.TabIndex = 10;
            btnsearchAddress.Text = "Search Customer By Address";
            btnsearchAddress.UseVisualStyleBackColor = true;
            btnsearchAddress.Click += btnsearchname_Click;
            // 
            // txtboxcustomerAddress
            // 
            txtboxcustomerAddress.Location = new Point(484, 176);
            txtboxcustomerAddress.Name = "txtboxcustomerAddress";
            txtboxcustomerAddress.Size = new Size(324, 31);
            txtboxcustomerAddress.TabIndex = 9;
            // 
            // AddressdataGridView1
            // 
            AddressdataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            AddressdataGridView1.Location = new Point(404, 243);
            AddressdataGridView1.Name = "AddressdataGridView1";
            AddressdataGridView1.RowHeadersWidth = 62;
            AddressdataGridView1.Size = new Size(568, 399);
            AddressdataGridView1.TabIndex = 8;
            AddressdataGridView1.CellContentClick += AddressdataGridView1_CellContentClick;
            // 
            // lblCustomerAddress
            // 
            lblCustomerAddress.AutoSize = true;
            lblCustomerAddress.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerAddress.Location = new Point(120, 177);
            lblCustomerAddress.Name = "lblCustomerAddress";
            lblCustomerAddress.Size = new Size(270, 30);
            lblCustomerAddress.TabIndex = 7;
            lblCustomerAddress.Text = "Address of the Customer";
            // 
            // CustomerAddressTitle
            // 
            CustomerAddressTitle.AutoSize = true;
            CustomerAddressTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerAddressTitle.Location = new Point(307, 71);
            CustomerAddressTitle.Name = "CustomerAddressTitle";
            CustomerAddressTitle.Size = new Size(521, 48);
            CustomerAddressTitle.TabIndex = 6;
            CustomerAddressTitle.Text = "Search Customer By Adddress";
            CustomerAddressTitle.Click += CustomerNameTitle_Click;
            // 
            // SearchByAddress
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1093, 725);
            Controls.Add(btnback);
            Controls.Add(btnsearchAddress);
            Controls.Add(txtboxcustomerAddress);
            Controls.Add(AddressdataGridView1);
            Controls.Add(lblCustomerAddress);
            Controls.Add(CustomerAddressTitle);
            Name = "SearchByAddress";
            Text = "SearchByAddress";
            ((System.ComponentModel.ISupportInitialize)AddressdataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchAddress;
        private TextBox txtboxcustomerAddress;
        private DataGridView AddressdataGridView1;
        private Label lblCustomerAddress;
        private Label CustomerAddressTitle;
    }
}