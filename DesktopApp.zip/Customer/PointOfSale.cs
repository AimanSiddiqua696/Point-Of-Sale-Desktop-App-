﻿using desktopapplication.Order;
using desktopapplication.Product;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace desktopapplication
{
    public partial class PointOfSale : Form
    {
        public PointOfSale()
        {
            InitializeComponent();
        }

        private void btnCustomermanagementsystemtitle_Click(object sender, EventArgs e)
        {
            CustomerForm customerform = new CustomerForm();
            customerform.Show();
        }

        private void btncustomeradvancefeatures_Click(object sender, EventArgs e)
        {
            AdvanceCustomerFeatures acf = new AdvanceCustomerFeatures();
            acf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ProductForm pf = new ProductForm();
            pf.Show();

        }

        private void btnAdvanceproductfeatures_Click(object sender, EventArgs e)
        {
            AdvanceSearchOptionsOfTheProduct form = new AdvanceSearchOptionsOfTheProduct();
            form.Show();
        }

        private void btnordermanagementsystem_Click(object sender, EventArgs e)
        {
            OrderForm f = new OrderForm();
            f.Show();
        }
    }
}
