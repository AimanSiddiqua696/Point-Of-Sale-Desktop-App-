using desktopapplication.Customer;
using Microsoft.Data.SqlClient;
using System.Data;

namespace desktopapplication
{
    public partial class CustomerForm : Form
    {

        string DBconnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        CustomerRepo repo = new CustomerRepo();
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string customername = txtboxCustomerName.Text;
            string address = txtboxCustomerAddress.Text;
            int age = Convert.ToInt32(txtboxCustomerAge.Text);
            string phoneno = txtboxCustomerContact.Text;

            CustomerModel customer = new CustomerModel(customername, address, age, phoneno);

            repo.Create(customer);

        }

        private void lblCustomerAge_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtboxId.Text);
            repo.Delete(id);
        }

        private void lblId_Click(object sender, EventArgs e)
        {

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtboxId.Text);
            string customername = txtboxCustomerName.Text;
            string address = txtboxCustomerAddress.Text;
            int age = int.Parse(txtboxCustomerAge.Text);
            string phonenumber = txtboxCustomerContact.Text;

            CustomerModel customer = new CustomerModel();
            customer.id = id;
            customer.cname = customername;
            customer.address = address;
            customer.age = age;
            customer.phonenumber = phonenumber;

            repo.Update(customer);
        }

        private void btnGrid_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(DBconnection))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1", sqlCon);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale pos = new PointOfSale();
            pos.Show();
            this.Hide();
        }

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(DBconnection))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1", sqlCon);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }
    }
}

