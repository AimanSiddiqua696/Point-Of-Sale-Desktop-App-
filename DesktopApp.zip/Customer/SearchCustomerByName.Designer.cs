﻿namespace desktopapplication
{
    partial class SearchCustomerByName
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CustomerNameTitle = new Label();
            lblCustomername = new Label();
            dataGridView1 = new DataGridView();
            txtboxcustomername = new TextBox();
            btnsearchname = new Button();
            btnback = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // CustomerNameTitle
            // 
            CustomerNameTitle.AutoSize = true;
            CustomerNameTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerNameTitle.Location = new Point(266, 49);
            CustomerNameTitle.Name = "CustomerNameTitle";
            CustomerNameTitle.Size = new Size(464, 48);
            CustomerNameTitle.TabIndex = 0;
            CustomerNameTitle.Text = "Search Customer By Name";
            // 
            // lblCustomername
            // 
            lblCustomername.AutoSize = true;
            lblCustomername.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomername.Location = new Point(79, 155);
            lblCustomername.Name = "lblCustomername";
            lblCustomername.Size = new Size(247, 30);
            lblCustomername.TabIndex = 1;
            lblCustomername.Text = "Name of the Customer";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(363, 221);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(568, 399);
            dataGridView1.TabIndex = 2;
            // 
            // txtboxcustomername
            // 
            txtboxcustomername.Location = new Point(443, 154);
            txtboxcustomername.Name = "txtboxcustomername";
            txtboxcustomername.Size = new Size(324, 31);
            txtboxcustomername.TabIndex = 3;
            // 
            // btnsearchname
            // 
            btnsearchname.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchname.Location = new Point(79, 251);
            btnsearchname.Name = "btnsearchname";
            btnsearchname.Size = new Size(193, 34);
            btnsearchname.TabIndex = 4;
            btnsearchname.Text = "SearchName";
            btnsearchname.UseVisualStyleBackColor = true;
            btnsearchname.Click += btnsearchname_Click;
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(79, 598);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 5;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // SearchCustomerByName
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1078, 693);
            Controls.Add(btnback);
            Controls.Add(btnsearchname);
            Controls.Add(txtboxcustomername);
            Controls.Add(dataGridView1);
            Controls.Add(lblCustomername);
            Controls.Add(CustomerNameTitle);
            Name = "SearchCustomerByName";
            Text = "SearchCustomerByName";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label CustomerNameTitle;
        private Label lblCustomername;
        private DataGridView dataGridView1;
        private TextBox txtboxcustomername;
        private Button btnsearchname;
        private Button btnback;
    }
}