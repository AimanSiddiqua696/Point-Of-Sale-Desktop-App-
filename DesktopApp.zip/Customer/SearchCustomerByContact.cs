﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication
{
    public partial class SearchCustomerByContact : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";


        public SearchCustomerByContact()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale ps = new PointOfSale();
            ps.Show();
        }

        private void btnsearchContact_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))

            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1 WHERE phonenumber = @phonenumber;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@phonenumber", txtboxcustomercontact.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                ContactdataGridView1.DataSource = dt;
            }
        }
    }
}
