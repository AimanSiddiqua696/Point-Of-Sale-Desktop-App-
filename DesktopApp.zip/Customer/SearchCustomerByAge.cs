﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace desktopapplication
{
    public partial class SearchCustomerByAge : Form
    {
        string DBConnection = @"Data Source=LocalHost; Initial Catalog=PointOfSale; Integrated Security=True; TrustServerCertificate=True;";

        public SearchCustomerByAge()
        {
            InitializeComponent();
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            PointOfSale pos = new PointOfSale();
            pos.Show();
        }

        private void btnsearchage_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlconn = new SqlConnection(DBConnection))
            {
                sqlconn.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM CUSTOMER1 WHERE age = @age;", sqlconn);

                sqlDa.SelectCommand.Parameters.AddWithValue("@age", txtboxcustomerage.Text);
                DataTable dt = new DataTable();
                sqlDa.Fill(dt);
                AgedataGridView1.DataSource = dt;
            }
        }
    }
}
