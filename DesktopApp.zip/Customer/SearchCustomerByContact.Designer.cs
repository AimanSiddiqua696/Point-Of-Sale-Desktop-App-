﻿namespace desktopapplication
{
    partial class SearchCustomerByContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchContact = new Button();
            txtboxcustomercontact = new TextBox();
            ContactdataGridView1 = new DataGridView();
            lblCustomerContact = new Label();
            CustomerContactTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)ContactdataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(144, 623);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 17;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchContact
            // 
            btnsearchContact.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchContact.Location = new Point(144, 276);
            btnsearchContact.Name = "btnsearchContact";
            btnsearchContact.Size = new Size(193, 34);
            btnsearchContact.TabIndex = 16;
            btnsearchContact.Text = "SearchContact";
            btnsearchContact.UseVisualStyleBackColor = true;
            btnsearchContact.Click += btnsearchContact_Click;
            // 
            // txtboxcustomercontact
            // 
            txtboxcustomercontact.Location = new Point(508, 179);
            txtboxcustomercontact.Name = "txtboxcustomercontact";
            txtboxcustomercontact.Size = new Size(324, 31);
            txtboxcustomercontact.TabIndex = 15;
            // 
            // ContactdataGridView1
            // 
            ContactdataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            ContactdataGridView1.Location = new Point(428, 246);
            ContactdataGridView1.Name = "ContactdataGridView1";
            ContactdataGridView1.RowHeadersWidth = 62;
            ContactdataGridView1.Size = new Size(568, 399);
            ContactdataGridView1.TabIndex = 14;
            // 
            // lblCustomerContact
            // 
            lblCustomerContact.AutoSize = true;
            lblCustomerContact.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerContact.Location = new Point(144, 180);
            lblCustomerContact.Name = "lblCustomerContact";
            lblCustomerContact.Size = new Size(267, 30);
            lblCustomerContact.TabIndex = 13;
            lblCustomerContact.Text = "Contact of the Customer";
            // 
            // CustomerContactTitle
            // 
            CustomerContactTitle.AutoSize = true;
            CustomerContactTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerContactTitle.Location = new Point(331, 74);
            CustomerContactTitle.Name = "CustomerContactTitle";
            CustomerContactTitle.Size = new Size(495, 48);
            CustomerContactTitle.TabIndex = 12;
            CustomerContactTitle.Text = "Search Customer By Contact";
            // 
            // SearchCustomerByContact
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1140, 730);
            Controls.Add(btnback);
            Controls.Add(btnsearchContact);
            Controls.Add(txtboxcustomercontact);
            Controls.Add(ContactdataGridView1);
            Controls.Add(lblCustomerContact);
            Controls.Add(CustomerContactTitle);
            Name = "SearchCustomerByContact";
            Text = "SearchCustomerByContact";
            ((System.ComponentModel.ISupportInitialize)ContactdataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchContact;
        private TextBox txtboxcustomercontact;
        private DataGridView ContactdataGridView1;
        private Label lblCustomerContact;
        private Label CustomerContactTitle;
    }
}