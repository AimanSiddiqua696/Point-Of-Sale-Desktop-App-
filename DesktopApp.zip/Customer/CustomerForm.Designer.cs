﻿namespace desktopapplication
{
    partial class CustomerForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCustomerTitle = new Label();
            lblCustomerName = new Label();
            lblCustomerAge = new Label();
            lblCustomerAddress = new Label();
            lblCustomerContact = new Label();
            txtboxCustomerName = new TextBox();
            txtboxCustomerAge = new TextBox();
            txtboxCustomerAddress = new TextBox();
            txtboxCustomerContact = new TextBox();
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnViewAll = new Button();
            lblId = new Label();
            txtboxId = new TextBox();
            btnGrid = new Button();
            btnback = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // lblCustomerTitle
            // 
            lblCustomerTitle.AutoSize = true;
            lblCustomerTitle.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerTitle.Location = new Point(180, 30);
            lblCustomerTitle.Name = "lblCustomerTitle";
            lblCustomerTitle.Size = new Size(422, 32);
            lblCustomerTitle.TabIndex = 0;
            lblCustomerTitle.Text = "CUSTOMER MANAGEMENT SYSTEM";
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerName.Location = new Point(108, 121);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(154, 25);
            lblCustomerName.TabIndex = 1;
            lblCustomerName.Text = "Customer Name";
            // 
            // lblCustomerAge
            // 
            lblCustomerAge.AutoSize = true;
            lblCustomerAge.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerAge.Location = new Point(108, 173);
            lblCustomerAge.Name = "lblCustomerAge";
            lblCustomerAge.Size = new Size(132, 25);
            lblCustomerAge.TabIndex = 2;
            lblCustomerAge.Text = "Customer Age";
            lblCustomerAge.Click += lblCustomerAge_Click;
            // 
            // lblCustomerAddress
            // 
            lblCustomerAddress.AutoSize = true;
            lblCustomerAddress.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerAddress.Location = new Point(108, 218);
            lblCustomerAddress.Name = "lblCustomerAddress";
            lblCustomerAddress.Size = new Size(166, 25);
            lblCustomerAddress.TabIndex = 3;
            lblCustomerAddress.Text = "Customer Address";
            // 
            // lblCustomerContact
            // 
            lblCustomerContact.AutoSize = true;
            lblCustomerContact.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerContact.Location = new Point(108, 273);
            lblCustomerContact.Name = "lblCustomerContact";
            lblCustomerContact.Size = new Size(164, 25);
            lblCustomerContact.TabIndex = 4;
            lblCustomerContact.Text = "Customer Contact";
            // 
            // txtboxCustomerName
            // 
            txtboxCustomerName.Location = new Point(286, 118);
            txtboxCustomerName.Name = "txtboxCustomerName";
            txtboxCustomerName.Size = new Size(150, 31);
            txtboxCustomerName.TabIndex = 5;
            // 
            // txtboxCustomerAge
            // 
            txtboxCustomerAge.Location = new Point(286, 170);
            txtboxCustomerAge.Name = "txtboxCustomerAge";
            txtboxCustomerAge.Size = new Size(150, 31);
            txtboxCustomerAge.TabIndex = 6;
            // 
            // txtboxCustomerAddress
            // 
            txtboxCustomerAddress.Location = new Point(286, 218);
            txtboxCustomerAddress.Name = "txtboxCustomerAddress";
            txtboxCustomerAddress.Size = new Size(150, 31);
            txtboxCustomerAddress.TabIndex = 7;
            // 
            // txtboxCustomerContact
            // 
            txtboxCustomerContact.Location = new Point(286, 273);
            txtboxCustomerContact.Name = "txtboxCustomerContact";
            txtboxCustomerContact.Size = new Size(150, 31);
            txtboxCustomerContact.TabIndex = 8;
            txtboxCustomerContact.TextChanged += textBox4_TextChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(481, 118);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(360, 225);
            dataGridView1.TabIndex = 9;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(82, 384);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(112, 34);
            btnAdd.TabIndex = 10;
            btnAdd.Text = "Add";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.Location = new Point(217, 384);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(112, 34);
            btnDelete.TabIndex = 11;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.Location = new Point(351, 384);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(112, 34);
            btnUpdate.TabIndex = 12;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnViewAll
            // 
            btnViewAll.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnViewAll.Location = new Point(491, 384);
            btnViewAll.Name = "btnViewAll";
            btnViewAll.Size = new Size(112, 34);
            btnViewAll.TabIndex = 13;
            btnViewAll.Text = "View All";
            btnViewAll.UseVisualStyleBackColor = true;
            btnViewAll.Click += btnViewAll_Click;
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblId.Location = new Point(75, 326);
            lblId.Name = "lblId";
            lblId.Size = new Size(201, 28);
            lblId.TabIndex = 14;
            lblId.Text = "Id(delete or update)";
            lblId.Click += lblId_Click;
            // 
            // txtboxId
            // 
            txtboxId.Location = new Point(282, 326);
            txtboxId.Name = "txtboxId";
            txtboxId.Size = new Size(150, 31);
            txtboxId.TabIndex = 15;
            // 
            // btnGrid
            // 
            btnGrid.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGrid.Location = new Point(517, 71);
            btnGrid.Name = "btnGrid";
            btnGrid.Size = new Size(155, 34);
            btnGrid.TabIndex = 16;
            btnGrid.Text = "GridButton";
            btnGrid.UseVisualStyleBackColor = true;
            btnGrid.Click += btnGrid_Click;
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(628, 384);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 17;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // CustomerForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1086, 664);
            Controls.Add(btnback);
            Controls.Add(btnGrid);
            Controls.Add(txtboxId);
            Controls.Add(lblId);
            Controls.Add(btnViewAll);
            Controls.Add(btnUpdate);
            Controls.Add(btnDelete);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(txtboxCustomerContact);
            Controls.Add(txtboxCustomerAddress);
            Controls.Add(txtboxCustomerAge);
            Controls.Add(txtboxCustomerName);
            Controls.Add(lblCustomerContact);
            Controls.Add(lblCustomerAddress);
            Controls.Add(lblCustomerAge);
            Controls.Add(lblCustomerName);
            Controls.Add(lblCustomerTitle);
            Name = "CustomerForm";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCustomerTitle;
        private Label lblCustomerName;
        private Label lblCustomerAge;
        private Label lblCustomerAddress;
        private Label lblCustomerContact;
        private TextBox txtboxCustomerName;
        private TextBox txtboxCustomerAge;
        private TextBox txtboxCustomerAddress;
        private TextBox txtboxCustomerContact;
        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnViewAll;
        private Label lblId;
        private TextBox txtboxId;
        private Button btnGrid;
        private Button btnback;
    }
}
