﻿namespace desktopapplication
{
    partial class SearchCustomerByFirstCharacter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnback = new Button();
            btnsearchCharacter = new Button();
            txtboxcustomeraddress = new TextBox();
            CharacterdataGridView1 = new DataGridView();
            lblCustomerfirstcharacter = new Label();
            CustomerFirstCharAgeTitle = new Label();
            ((System.ComponentModel.ISupportInitialize)CharacterdataGridView1).BeginInit();
            SuspendLayout();
            // 
            // btnback
            // 
            btnback.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnback.Location = new Point(117, 606);
            btnback.Name = "btnback";
            btnback.Size = new Size(112, 34);
            btnback.TabIndex = 17;
            btnback.Text = "Back";
            btnback.UseVisualStyleBackColor = true;
            btnback.Click += btnback_Click;
            // 
            // btnsearchCharacter
            // 
            btnsearchCharacter.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnsearchCharacter.Location = new Point(117, 259);
            btnsearchCharacter.Name = "btnsearchCharacter";
            btnsearchCharacter.Size = new Size(234, 34);
            btnsearchCharacter.TabIndex = 16;
            btnsearchCharacter.Text = "Search First Character";
            btnsearchCharacter.UseVisualStyleBackColor = true;
            btnsearchCharacter.Click += btnsearchCharacter_Click;
            // 
            // txtboxcustomeraddress
            // 
            txtboxcustomeraddress.Location = new Point(481, 162);
            txtboxcustomeraddress.Name = "txtboxcustomeraddress";
            txtboxcustomeraddress.Size = new Size(324, 31);
            txtboxcustomeraddress.TabIndex = 15;
            // 
            // CharacterdataGridView1
            // 
            CharacterdataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            CharacterdataGridView1.Location = new Point(401, 229);
            CharacterdataGridView1.Name = "CharacterdataGridView1";
            CharacterdataGridView1.RowHeadersWidth = 62;
            CharacterdataGridView1.Size = new Size(568, 399);
            CharacterdataGridView1.TabIndex = 14;
            // 
            // lblCustomerfirstcharacter
            // 
            lblCustomerfirstcharacter.AutoSize = true;
            lblCustomerfirstcharacter.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCustomerfirstcharacter.Location = new Point(117, 163);
            lblCustomerfirstcharacter.Name = "lblCustomerfirstcharacter";
            lblCustomerfirstcharacter.Size = new Size(338, 30);
            lblCustomerfirstcharacter.TabIndex = 13;
            lblCustomerfirstcharacter.Text = "First Character of the Customer";
            // 
            // CustomerFirstCharAgeTitle
            // 
            CustomerFirstCharAgeTitle.AutoSize = true;
            CustomerFirstCharAgeTitle.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            CustomerFirstCharAgeTitle.Location = new Point(304, 57);
            CustomerFirstCharAgeTitle.Name = "CustomerFirstCharAgeTitle";
            CustomerFirstCharAgeTitle.Size = new Size(608, 48);
            CustomerFirstCharAgeTitle.TabIndex = 12;
            CustomerFirstCharAgeTitle.Text = "Search Customer By First Character";
            // 
            // SearchCustomerByFirstCharacter
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1086, 696);
            Controls.Add(btnback);
            Controls.Add(btnsearchCharacter);
            Controls.Add(txtboxcustomeraddress);
            Controls.Add(CharacterdataGridView1);
            Controls.Add(lblCustomerfirstcharacter);
            Controls.Add(CustomerFirstCharAgeTitle);
            Name = "SearchCustomerByFirstCharacter";
            Text = "SearchCustomerByFirstCharacter";
            ((System.ComponentModel.ISupportInitialize)CharacterdataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnback;
        private Button btnsearchCharacter;
        private TextBox txtboxcustomerage;
        private DataGridView CharacterdataGridView1;
        private Label lblCustomerfirstcharacter;
        private Label CustomerFirstCharAgeTitle;
        private TextBox txtboxcustomeraddress;
    }
}